export const PLATFORMS = Object.freeze([
  { id: 'douyin', label: '抖音', hosts: ['www.douyin.com', 'douyin.com'], enabled: true },
  { id: 'xiaohongshu', label: '小红书', hosts: ['www.xiaohongshu.com', 'xiaohongshu.com'], enabled: false },
  { id: 'bilibili', label: '哔哩哔哩', hosts: ['www.bilibili.com', 'bilibili.com'], enabled: false },
  { id: 'wechat', label: '微信公众号', hosts: ['mp.weixin.qq.com'], enabled: false },
].map(item => Object.freeze({ ...item, hosts: Object.freeze(item.hosts) })));

export function sourcePlatform(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password ? PLATFORMS.find(item => item.hosts.includes(url.hostname)) ?? null : null;
  } catch { return null; }
}

export function describeSource(value) {
  try {
    const url = new URL(value);
    const platform = sourcePlatform(value);
    if (!platform) return '暂不支持此页面';
    if (!platform.enabled) return `${platform.label} · 暂未开放，敬请期待！`;
    if (/^\/video\//.test(url.pathname) || url.searchParams.has('modal_id')) return '抖音 · 视频详情';
    if (/^\/note\//.test(url.pathname)) return '抖音 · 图文详情';
    if (/^\/search/.test(url.pathname)) return '抖音 · 搜索';
    if (/^\/user\//.test(url.pathname)) return '抖音 · 作者主页';
    return '抖音 · 首页推荐';
  } catch { return '暂不支持此页面'; }
}
