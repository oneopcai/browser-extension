(() => {
  const api = globalThis.chrome;
  let runtime, storage, messageEvents, settingsEvents, extensionId;
  try {
    runtime = api?.runtime; storage = api?.storage; extensionId = runtime?.id;
    messageEvents = runtime?.onMessage; settingsEvents = storage?.onChanged;
    if (!extensionId || typeof runtime?.sendMessage !== 'function'
        || typeof messageEvents?.addListener !== 'function' || typeof messageEvents?.removeListener !== 'function'
        || typeof settingsEvents?.addListener !== 'function' || typeof settingsEvents?.removeListener !== 'function'
        || typeof storage?.sync?.get !== 'function') return;
  } catch { return; }
  if (globalThis.__oneopcaiClipperRunning) return;
  globalThis.__oneopcaiClipperRunning = true;
  const { scan, identify } = globalThis.OneOPCAIClipperCards;
  const records = new Map(), states = new Map();
  const pendingTitles = new Set();
  let pageUrls = new Set();
  let disposed = false, lastPointer = null, timer, bubbleTimer, announcementTimer, recognizedTotal = 0, lastCount = null, nextAnnouncementAt = 0, expanded = false, previousHref = location.href, displayMode = 'hover', settingsReady = false, hoverListening = false, settingRevision = 0;
  let observer, resizeObserver, routeTimer, listener, layoutChanged, playerHover, playerLoaded, observedNavigation = null;
  function contextAvailable() {
    try { return globalThis.chrome === api && api.runtime === runtime && runtime.id === extensionId; }
    catch { return false; }
  }
  function active() {
    if (disposed) return false;
    if (!contextAvailable()) { stop(); return false; }
    return true;
  }
  async function send(message) {
    if (!active()) throw new Error('extension_context_unavailable');
    try { return await runtime.sendMessage(message); }
    catch (error) {
      if (!contextAvailable() || /extension context invalidated/i.test(error?.message ?? '')) stop();
      throw error;
    }
  }
  const css = ':host{all:initial;font-family:system-ui,sans-serif;color-scheme:light}button{cursor:pointer;border:1px solid #fc793e;border-radius:18px;padding:7px 12px;font:600 13px system-ui;background:#101e3c;color:#fff;box-shadow:0 2px 8px #0004;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}button:focus-visible{outline:3px solid #2acfff;outline-offset:2px}button:disabled{cursor:default;opacity:.8}.note{display:block;max-width:260px;font:12px/1.4 system-ui;background:#101e3c;color:#fff;padding:5px;border-radius:6px;margin-top:4px}.note[hidden]{display:none}';
  const entryCss = `
    .orb{display:block;width:44px;height:44px;max-width:100%;padding:0;border-radius:50%;font:700 14px/1 system-ui;font-variant-numeric:tabular-nums;position:relative;overflow:visible;background:linear-gradient(145deg,#253f67,#101e3c);box-shadow:0 3px 12px #0003}
    .orb[data-digits="4"]{font-size:12px}.orb[data-digits="5"]{font-size:10px}
    .orb[data-state="login"]::after,.orb[data-state="error"]::after{content:"";position:absolute;width:8px;height:8px;right:0;top:0;border:2px solid #fff;border-radius:50%;background:#f88b43}
    .entry-card{position:absolute;left:0;top:52px;width:280px;max-width:var(--entry-width,280px);box-sizing:border-box;border:1px solid #fa8749;border-radius:12px;background:#101e3c;color:#fff;padding:12px;box-shadow:0 6px 24px #0003;font:13px/1.6 system-ui;overflow-wrap:anywhere;animation:arrive .14s ease-out}
    .entry-card[hidden]{display:none}.bubble{pointer-events:none}.entry-title{margin:0 0 10px}.entry-open{width:100%;background:#f98343;color:#101e3c;border:0;border-radius:8px;box-shadow:none}
    @keyframes arrive{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
    @media(prefers-reduced-motion:reduce){.entry-card{animation:none}}
  `;
  function surface() {
    const host = document.createElement('span');
    host.dataset.oneopcaiClipper = 'true';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style'); style.textContent = css; root.append(style);
    return { host, root };
  }
  const panel = surface();
  panel.host.style.cssText = 'position:fixed;z-index:2147483647;max-width:360px';
  const entryStyle = document.createElement('style'); entryStyle.textContent = entryCss; panel.root.append(entryStyle);
  const summary = document.createElement('button'); summary.type = 'button'; summary.className = 'orb';
  summary.setAttribute('aria-expanded', 'false'); summary.setAttribute('aria-controls', 'entry-details');
  const detail = document.createElement('div'); detail.id = 'entry-details'; detail.className = 'entry-card'; detail.hidden = true;
  const entryTitle = document.createElement('p'); entryTitle.className = 'entry-title';
  const openPanel = document.createElement('button'); openPanel.type = 'button'; openPanel.className = 'entry-open'; openPanel.textContent = '打开插件助手 ↗';
  openPanel.dataset.entrySecondary = 'true'; detail.append(entryTitle, openPanel);
  const bubble = document.createElement('div'); bubble.className = 'entry-card bubble'; bubble.hidden = true;
  bubble.setAttribute('role', 'status'); bubble.setAttribute('aria-live', 'polite'); bubble.setAttribute('aria-atomic', 'true');
  panel.root.append(summary, detail, bubble);
  let entryState = '';
  document.documentElement.append(panel.host);
  function setExpanded(value) {
    expanded = value; detail.hidden = !value; summary.setAttribute('aria-expanded', String(value));
    bubble.hidden = true; clearTimeout(announcementTimer); announcementTimer = null;
  }
  function announceCount() {
    if (disposed || expanded || !bubble.hidden) return;
    const wait = nextAnnouncementAt - Date.now();
    if (wait > 0) {
      if (!announcementTimer) announcementTimer = setTimeout(() => { announcementTimer = null; announceCount(); }, wait);
      return;
    }
    bubble.hidden = false; nextAnnouncementAt = Date.now() + 10000;
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(() => { bubble.hidden = true; bubbleTimer = null; }, 3000);
  }
  summary.addEventListener('click', event => { if (event.isTrusted) setExpanded(!expanded); });
  openPanel.addEventListener('click', event => {
    if (!event.isTrusted) return;
    send({ type: 'clipper.open' }).catch(() => { if (!disposed) summary.title = '插件连接已失效，请刷新页面'; });
  });
  panel.root.addEventListener('keydown', event => {
    if (event.key === 'Escape' && expanded) { setExpanded(false); summary.focus(); event.stopPropagation(); }
  });

  function updateVisibility(record) {
    const visible = displayMode === 'all' || record.hovered || record.focused;
    const opacity = visible ? '1' : '0', pointerEvents = visible ? 'auto' : 'none';
    if (record.host.style.opacity !== opacity) record.host.style.opacity = opacity;
    if (record.host.style.pointerEvents !== pointerEvents) record.host.style.pointerEvents = pointerEvents;
  }
  function insideInteraction(record, node, x, y) {
    if (node instanceof Node && (record.owner.contains(node) || record.host.contains(node) || record.root.contains(node))) return true;
    return [record.target, record.host].some(element => {
      const box = element.getBoundingClientRect();
      return box.width > 0 && box.height > 0 && x >= box.left && x <= box.right && y >= box.top && y <= box.bottom;
    });
  }
  const cardBoundary = 'div.jingxuanVideoCard[href],[data-e2e="user-post-item"],[data-e2e="search-result"],li,article';
  function instanceFor(item, items) {
    const semantic = item.element.closest(cardBoundary);
    const feed = item.element.closest('[data-e2e="feed-active-video"],[data-e2e="recommend-feed-item"],[data-e2e="feed-item"]');
    const ancestors = [];
    for (let node = item.element; node && node !== document.body && node !== document.documentElement; node = node.parentElement) ancestors.push(node);
    const parent = item.element.parentElement;
    const linkContainers = ancestors.filter(node => node.matches('div,section') && node.querySelector('a[href]'));
    const identities = ancestors.filter(node => node.matches('[data-aweme-id],[data-video-id],[data-item-id]')).reverse();
    const structural = new Set([semantic, feed, ...identities]);
    for (const owner of new Set([semantic, ...linkContainers, feed, ...identities, parent?.matches('div,section') ? parent : null])) {
      if (!owner || owner === document.body || owner === document.documentElement) continue;
      // A view belongs to one occurrence, never to a broad wrapper or a URL alone.
      const peers = items.filter(other => owner.contains(other.element));
      if (peers.length > 1) {
        const media = peers.filter(other => other.placement === 'player');
        const links = peers.filter(other => other.placement !== 'player');
        const established = records.get(owner)?.item.permalink === item.permalink;
        const previewPair = media.length === 1 && links.length > 0
          && peers.every(other => other.permalink === item.permalink)
          && links.every(other => other.element.matches('a[href],div.jingxuanVideoCard[href]')
            && (established || other.element === owner || other.element.parentElement === owner));
        if (!previewPair) continue;
      }
      const links = new Set([...owner.querySelectorAll('a[href]')].map(link => identify?.(link.getAttribute('href'), location.href)?.permalink).filter(Boolean));
      if (links.size > 1 || (links.size === 1 && !links.has(item.permalink))) continue;
      if (!structural.has(owner) && !links.size && owner.querySelectorAll('video').length !== 1) continue;
      return owner;
    }
    return item.element;
  }
  function geometryFor(item, owner) {
    const box = owner.getBoundingClientRect();
    return box.width > 0 && box.height > 0 ? owner : item.element;
  }
  function retarget(record, item) {
    record.item = item;
    const target = geometryFor(item, record.owner);
    if (target === record.target) return;
    if (record.target !== record.owner) resizeObserver?.unobserve(record.target);
    record.target = target; resizeObserver?.observe(target);
  }
  function removeRecord(owner, record) {
    record.cleanups.forEach(cleanup => cleanup());
    record.host.remove(); records.delete(owner);
  }
  function stopRecordHover(record) {
    for (const remove of record.hoverCleanups.splice(0)) remove();
    record.hovered = false;
  }
  function syncRecordHover(record) {
    if (disposed || !settingsReady || displayMode !== 'hover') { stopRecordHover(record); return; }
    if (record.hoverCleanups.length) return;
    record.hovered = record.hoverTarget.matches(':hover') || record.host.matches(':hover');
    for (const element of [record.hoverTarget, record.host]) {
      const enter = () => {
        if (disposed || displayMode !== 'hover') return;
        record.hovered = true; positionCard(record); updateVisibility(record);
      };
      const leave = event => {
        if (disposed || displayMode !== 'hover') return;
        record.hovered = insideInteraction(record, event.relatedTarget, event.clientX, event.clientY); updateVisibility(record);
      };
      element.addEventListener('pointerenter', enter, { passive: true });
      element.addEventListener('pointerleave', leave, { passive: true });
      record.hoverCleanups.push(() => {
        element.removeEventListener('pointerenter', enter);
        element.removeEventListener('pointerleave', leave);
      });
    }
  }
  function syncHoverEvents() {
    const needed = !disposed && settingsReady && displayMode === 'hover';
    if (needed !== hoverListening) {
      if (needed) window.addEventListener('pointermove', playerHover, { capture: true, passive: true });
      else window.removeEventListener('pointermove', playerHover, true);
      hoverListening = needed;
    }
    for (const record of records.values()) syncRecordHover(record);
  }
  function applyDisplayMode(value) {
    const next = value === 'all' ? 'all' : 'hover';
    if (next !== displayMode) lastPointer = null;
    displayMode = next; syncHoverEvents();
    for (const record of records.values()) { positionCard(record); updateVisibility(record); }
  }
  function settingsChanged(changes, area) {
    if (!active() || area !== 'sync' || !Object.hasOwn(changes, 'buttonDisplayMode')) return;
    settingRevision++; settingsReady = true; applyDisplayMode(changes.buttonDisplayMode.newValue);
  }
  function render(record) {
    const state = states.get(record.item.permalink);
    const disabled = ['saving', 'saved'].includes(state?.state);
    const text = state?.state === 'saved' ? '✓ 已收藏'
      : state?.state === 'saving' ? '收藏中…' : state?.state === 'login' ? '请先登录'
      : state?.state === 'error' ? '重试收藏' : '+ 收藏到 OneOPCAI';
    const title = state?.state === 'login' ? '请先登录后继续收藏，点击打开插件助手' : state?.message || record.item.title || record.item.permalink;
    const label = state?.state === 'login' ? '请先登录后继续收藏，点击打开插件助手' : '收藏这条内容到 OneOPCAI';
    if (record.button.disabled !== disabled) record.button.disabled = disabled;
    if (record.button.textContent !== text) record.button.textContent = text;
    if (record.button.title !== title) record.button.title = title;
    if (record.button.getAttribute('aria-label') !== label) record.button.setAttribute('aria-label', label);
    updateVisibility(record);
  }
  function accept(result) {
    if (!active() || !result?.rawUrl || !['saving', 'login', 'saved', 'error'].includes(result.state)) return;
    states.set(result.rawUrl, result);
    for (const record of records.values()) if (record.item.permalink === result.rawUrl) render(record);
    entryState = result.state;
    refreshSummary();
  }
  function currentItem(record, permalink) {
    if (!active() || !record.owner.isConnected) return null;
    const items = scan(document, location.href);
    return items.find(candidate => candidate.permalink === permalink && instanceFor(candidate, items) === record.owner) ?? null;
  }
  function readTitleAtClick(record, permalink) {
    const current = currentItem(record, permalink);
    if (!current || current.title) return Promise.resolve(current);
    // Wait only for this explicit user intent. Never borrow another work's title.
    return new Promise(resolve => {
      let done = false;
      const finish = value => {
        if (done) return;
        done = true; changes.disconnect(); clearTimeout(deadline); pendingTitles.delete(cancel); resolve(value);
      };
      const cancel = () => finish(null);
      const changes = new MutationObserver(() => {
        const item = currentItem(record, permalink);
        if (!item || item.title) finish(item);
      });
      const deadline = setTimeout(() => finish(currentItem(record, permalink)), 1200);
      pendingTitles.add(cancel);
      changes.observe(record.owner, { subtree: true, childList: true, characterData: true, attributes: true,
        attributeFilter: ['href', 'title', 'alt', 'aria-label', 'data-aweme-id', 'data-video-id', 'data-item-id'] });
    });
  }
  function attach(item, owner) {
    const ui = surface(), button = document.createElement('button');
    button.type = 'button'; button.setAttribute('aria-label', '收藏这条内容到 OneOPCAI');
    ui.root.append(button);
    // Every mode uses this same portal and source rectangle. Source-page layout is never mutated.
    const target = geometryFor(item, owner);
    ui.host.style.cssText = 'all:initial;display:none;position:fixed;z-index:2147483000;left:auto;max-width:280px;margin:0;padding:0;border:0;transform:none';
    document.documentElement.append(ui.host);
    const hoverTarget = owner;
    const record = { ...ui, button, item, owner, target, hoverTarget,
      hovered: false, focused: false, hoverCleanups: [], cleanups: [] }; records.set(owner, record);
    resizeObserver?.observe(owner); if (target !== owner) resizeObserver?.observe(target);
    record.cleanups.push(() => { resizeObserver?.unobserve(record.target); resizeObserver?.unobserve(owner); }, () => stopRecordHover(record));
    function listen(element, event, handler) {
      element.addEventListener(event, handler);
      record.cleanups.push(() => element.removeEventListener(event, handler));
    }
    syncRecordHover(record);
    listen(ui.host, 'focusin', () => { record.focused = true; updateVisibility(record); });
    listen(ui.host, 'focusout', event => { record.focused = event.relatedTarget instanceof Node && ui.root.contains(event.relatedTarget); updateVisibility(record); });
    button.addEventListener('click', async event => {
      event.preventDefault(); event.stopPropagation();
      if (!event.isTrusted || button.disabled || !active()) return;
      if (states.get(record.item.permalink)?.state === 'login') {
        send({ type: 'clipper.open' }).catch(() => { if (!disposed) summary.title = '插件连接已失效，请刷新页面'; });
        return;
      }
      // Virtualized feeds may recycle a card between scans. Resolve its identity at the click.
      const permalink = record.item.permalink;
      accept({ rawUrl: permalink, state: 'saving', message: '正在读取当前作品标题…' });
      const resolved = await readTitleAtClick(record, permalink);
      const current = resolved && currentItem(record, permalink);
      if (!active()) return;
      if (!current) {
        accept({ rawUrl: permalink, state: 'error', message: '内容已更新，请确认后重新点击收藏' });
        refresh(); summary.title = '内容已更新，请确认后重新点击收藏'; return;
      }
      accept({ rawUrl: current.permalink, state: 'saving', message: '正在确认平台登录状态并收藏…' });
      send({ type: 'clipper.save', data: { permalink: current.permalink, title: current.title,
        author: current.author, pageType: current.pageType } }).then(result => {
        if (!result || !['saving', 'login', 'saved', 'error'].includes(result.state)) {
          accept({ rawUrl: current.permalink, state: 'error', message: '未收到有效插件响应，请重试' }); return;
        }
        accept({ ...result, rawUrl: current.permalink });
      }).catch(() => accept({ rawUrl: current.permalink, state: 'error', message: '插件连接已失效，请刷新页面后重试' }));
    });
    render(record);
  }
  function refresh() {
    if (!active()) return;
    const items = scan(document, location.href), current = new Map();
    for (const item of items) {
      const owner = instanceFor(item, items);
      if (!current.has(owner) || item.placement === 'player') current.set(owner, item);
    }
    pageUrls = new Set(items.map(item => item.permalink));
    recognizedTotal = pageUrls.size;
    for (const [owner, record] of records) if (!current.has(owner) || !record.host.isConnected || current.get(owner).permalink !== record.item.permalink) {
      removeRecord(owner, record);
    }
    for (const [owner, item] of current) {
      const existing = records.get(owner);
      if (!existing) attach(item, owner);
      else { retarget(existing, item); render(existing); }
    }
    refreshSummary(); positionEntry();
  }
  function refreshSummary() {
    const count = recognizedTotal, text = `OneOPCAI Clipper 已识别 ${count} 条内容`;
    summary.textContent = String(count); summary.dataset.digits = String(Math.min(5, String(count).length));
    summary.dataset.state = entryState;
    summary.setAttribute('aria-label', `${text}，${entryState === 'login' ? '请先登录后继续收藏，' : entryState === 'error' ? '收藏需重试，' : ''}点击展开或收起`);
    summary.title = entryState === 'login' ? '请先登录后继续收藏，展开后打开插件助手' : entryState === 'error' ? '收藏需重试，展开后打开插件助手' : text;
    if (entryTitle.textContent !== text) entryTitle.textContent = text;
    if (count !== lastCount) {
      // Coalesce bursts without extending the display window or stealing focus.
      if (bubble.textContent !== text) bubble.textContent = text;
      if (lastCount !== null || count > 0) announceCount();
      lastCount = count;
    }
  }

  function positionEntry() {
    if (!active()) return;
    const box = globalThis.OneOPCAIClipperPlacement(document, innerWidth, innerHeight);
    panel.host.style.left = `${box.left}px`; panel.host.style.top = `${box.top}px`;
    panel.host.style.maxWidth = `${box.maxWidth}px`;
    panel.host.style.setProperty('--entry-width', `${Math.min(280, box.maxWidth)}px`);
    if (box.anchor !== observedNavigation) {
      if (observedNavigation) resizeObserver?.unobserve(observedNavigation);
      observedNavigation = box.anchor;
      if (observedNavigation) resizeObserver?.observe(observedNavigation);
    }
    for (const record of records.values()) positionCard(record);
  }
  function positionCard(record) {
    const rect = record.target.getBoundingClientRect();
    const left = Math.max(8, rect.left + 12), right = Math.min(innerWidth - 8, rect.right - 12);
    const visible = rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight
      && rect.right > 0 && rect.left < innerWidth && right > left;
    record.host.style.display = visible ? 'inline-block' : 'none';
    // Anchor the actual right edge, irrespective of button text, hover or storage timing.
    record.host.style.right = `${Math.max(8, innerWidth - right)}px`;
    record.host.style.top = `${rect.top + 12}px`;
    record.host.style.maxWidth = `${Math.max(0, right - left)}px`;
    if (visible && !globalThis.OneOPCAIClipperButtonVisible(document, record.target, record.button, right, rect.top + 12, record.item.permalink)) record.host.style.display = 'none';
    if (settingsReady && displayMode === 'hover' && lastPointer && record.item.placement === 'player') {
      record.hovered = insideInteraction(record, null, lastPointer.x, lastPointer.y);
      updateVisibility(record);
    }
  }
  observer = new MutationObserver(mutations => {
    if (!active()) return;
    if (mutations.every(mutation => (mutation.target.nodeType === Node.ELEMENT_NODE ? mutation.target : mutation.target.parentElement)?.closest('[data-oneopcai-clipper]'))) return;
    if (!timer) timer = setTimeout(() => { timer = null; refresh(); }, 250);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true,
    attributeFilter: ['href', 'title', 'alt', 'aria-label', 'data-feed-ad-click-refer', 'data-aweme-id', 'data-video-id', 'data-item-id', 'data-e2e', 'data-live-room-id', 'data-room-id', 'data-content-type', 'class', 'style', 'hidden', 'aria-hidden'] });
  routeTimer = setInterval(() => { if (!active()) return; if (location.href !== previousHref) { previousHref = location.href; refresh(); } }, 1000);
  listener = (message, sender, reply) => {
    if (!active()) return;
    if (message?.type === 'clipper.result') accept(message.result);
    if (message?.type === 'clipper.context:get') {
      refresh();
      const savedTotal = [...pageUrls].filter(url => states.get(url)?.state === 'saved').length;
      reply?.({ url: location.href, title: document.title, total: recognizedTotal, savedTotal });
    }
  };
  layoutChanged = () => { positionEntry(); if (!disposed && !timer) timer = setTimeout(() => { timer = null; refresh(); }, 250); };
  window.addEventListener('resize', layoutChanged, { passive: true }); window.addEventListener('scroll', layoutChanged, { capture: true, passive: true });
  playerHover = event => {
    if (disposed || !settingsReady || displayMode !== 'hover') return;
    lastPointer = { x: event.clientX, y: event.clientY };
    for (const record of records.values()) if (record.item.placement === 'player') {
      record.hovered = insideInteraction(record, event.target, event.clientX, event.clientY);
      updateVisibility(record);
    }
  };
  playerLoaded = event => { if (event.target?.tagName === 'VIDEO') { refresh(); positionEntry(); } };
  document.addEventListener('loadedmetadata', playerLoaded, true); document.addEventListener('canplay', playerLoaded, true);
  resizeObserver = typeof ResizeObserver === 'function' ? new ResizeObserver(() => positionEntry()) : null;
  resizeObserver?.observe(document.documentElement);
  function stop() {
    if (disposed) return;
    disposed = true; clearInterval(routeTimer); clearTimeout(timer); clearTimeout(bubbleTimer); clearTimeout(announcementTimer);
    for (const cancel of pendingTitles) cancel();
    observer?.disconnect(); resizeObserver?.disconnect(); window.removeEventListener('resize', layoutChanged); window.removeEventListener('scroll', layoutChanged, true);
    syncHoverEvents(); document.removeEventListener('loadedmetadata', playerLoaded, true); document.removeEventListener('canplay', playerLoaded, true);
    window.removeEventListener('pagehide', pageHidden);
    // Cached event handles can themselves reject after an extension reload. Attempt both independently.
    try { messageEvents.removeListener(listener); } catch { /* This context no longer owns an active extension listener. */ }
    try { settingsEvents.removeListener(settingsChanged); } catch { /* DOM cleanup must still complete. */ }
    for (const [owner, record] of records) removeRecord(owner, record);
    panel.host.remove(); states.clear(); pageUrls.clear(); globalThis.__oneopcaiClipperRunning = false;
  }
  function pageHidden(event) { if (!event.persisted) stop(); }
  window.addEventListener('pagehide', pageHidden);
  const initialRevision = settingRevision;
  try {
    messageEvents.addListener(listener); settingsEvents.addListener(settingsChanged);
    Promise.resolve(storage.sync.get('buttonDisplayMode')).then(stored => {
      if (active() && settingRevision === initialRevision) { settingsReady = true; applyDisplayMode(stored?.buttonDisplayMode); }
    }, () => { if (active() && settingRevision === initialRevision) { settingsReady = true; applyDisplayMode('hover'); } });
  } catch { stop(); return; }
  refresh();
  send({ type: 'clipper.status' }).then(results => { if (active() && Array.isArray(results)) results.forEach(accept); }, () => {});
})();
