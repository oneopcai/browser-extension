// Content-script isolated-world module; no dependency on page globals or Web code.
(() => {
  const feedSelector = '[data-e2e="feed-active-video"], [data-e2e="recommend-feed-item"], [data-e2e="feed-item"]';
  const identitySelector = '[data-aweme-id],[data-video-id],[data-item-id]';
  // The rendered Jingxuan cards use DIV[href], not anchor elements.
  const linkSelector = 'a[href], div.jingxuanVideoCard[href]';
  const liveSelector = '[data-e2e="feed-live"],[data-e2e="feed-live-item"],[data-e2e="live-player"],[data-live-room-id],[data-room-id],[data-content-type="live"]';
  const cardSelector = `${feedSelector}, div.jingxuanVideoCard[href], [data-e2e="user-post-item"], [data-e2e="search-result"], li, article`;
  const domId = element => element && (element.getAttribute('data-aweme-id') || element.getAttribute('data-video-id') || element.getAttribute('data-item-id'));
  const cleanText = value => typeof value === 'string' ? value.trim() : '';
  const firstText = (...values) => values.map(cleanText).find(Boolean) || '';
  const descriptionSelector = '[data-feed-ad-click-refer="title"], [data-e2e="video-desc"], [data-e2e="video-description"], [data-e2e="video-title"], [data-e2e="user-post-item-desc"], [data-e2e="search-result-desc"]';
  const authorSelector = '[data-feed-ad-click-refer="name"], [data-e2e="video-author-name"], [data-e2e="video-author"]';
  function isLive(element, href) {
    if (element.closest(liveSelector)) return true;
    const scope = element.closest(feedSelector) ?? element.closest('li,article');
    if (!scope) return false;
    const links = [...scope.querySelectorAll(linkSelector)];
    const liveLink = links.some(link => {
      try { const url = new URL(link.getAttribute('href'), href); return url.hostname === 'live.douyin.com' || (['www.douyin.com','douyin.com'].includes(url.hostname) && /^\/live(?:\/|$)/.test(url.pathname)); } catch { return false; }
    });
    // A room link alone is not a video, even when its numeric ID is reused in a generic item attribute.
    return liveLink && !links.some(link => identify(link.getAttribute('href'), href)?.pageType === 'video');
  }
  function identify(value, base) {
    try {
      const u = new URL(value, base);
      if (u.username || u.password || u.protocol !== 'https:') return null;
      if (['douyin.com', 'www.douyin.com'].includes(u.hostname)) {
        const match = u.pathname.match(/^\/(video|note)\/(\d+)(?:\/|$)/);
        const modal = u.searchParams.get('modal_id');
        if (match) return { permalink: `https://www.douyin.com/${match[1]}/${match[2]}`, pageType: match[1] === 'video' ? 'video' : 'article' };
        if (modal && /^\d+$/.test(modal)) return { permalink: `https://www.douyin.com/video/${modal}`, pageType: 'video' };
      }
      if (u.hostname === 'mp.weixin.qq.com' && /^\/s(?:\/|$)/.test(u.pathname)) return { permalink: u.href, pageType: 'article' };
    } catch { /* Not a public content link. */ }
    return null;
  }
  function scan(document, href) {
    const page = new URL(href), results = [], used = new Set(), blocked = new Set();
    const identityCache = new WeakMap();
    function boundScope(element, item) {
      let lastSafe = element;
      let scope = element;
      for (let depth = 0; scope && depth < 8 && !['BODY', 'HTML'].includes(scope.tagName); depth++, scope = scope.parentElement) {
        let identities = identityCache.get(scope);
        if (!identities) {
          identities = new Set([...(scope.matches(linkSelector) ? [scope] : []), ...scope.querySelectorAll(linkSelector)]
            .map(link => identify(link.getAttribute('href'), href)?.permalink).filter(Boolean));
          const ownerId = domId(scope);
          if (ownerId) identities.add(identify(`/${item.pageType === 'article' ? 'note' : 'video'}/${ownerId}`, href)?.permalink);
          identityCache.set(scope, identities);
        }
        if ([...identities].some(value => value && value !== item.permalink)) break;
        lastSafe = scope;
        if (scope.querySelector(`${descriptionSelector}, h1, h2, h3`)) return scope;
        // A real link-bearing card owns its title/cover; do not escape to its siblings.
        if (scope.matches('div.jingxuanVideoCard[href]')) return scope;
      }
      return lastSafe;
    }
    function titleFor(element, item) {
      const scope = boundScope(element, item);
      const visibleText = selector => [...(scope?.querySelectorAll(selector) || [])]
        .filter(node => !node.closest('[hidden], [aria-hidden="true"]'))
        .map(node => node.textContent).find(value => cleanText(value));
      const anchor = element.matches(linkSelector) ? element : [...(scope || element).querySelectorAll(linkSelector)]
        .find(link => identify(link.getAttribute('href'), href)?.permalink === item.permalink);
      const direct = firstText(visibleText(descriptionSelector), anchor?.getAttribute('title'),
        visibleText('h1,h2,h3'), anchor?.getAttribute('aria-label'), anchor?.querySelector('img[alt]')?.getAttribute('alt'),
        anchor?.tagName === 'A' ? anchor.textContent : '');
      if (direct) return direct;
      // Only a standalone current detail may use page metadata. List cards must
      // never borrow a neighboring work or the whole page's title.
      if (!/^\/(video|note)\/\d+\/?$/.test(page.pathname) || identify(href, href)?.permalink !== item.permalink) return '';
      const declared = document.querySelector('meta[property="og:url"]')?.getAttribute('content');
      const declaredItem = declared && identify(declared, href);
      if (declaredItem && declaredItem.permalink !== item.permalink) return '';
      return [document.querySelector('meta[property="og:title"]')?.getAttribute('content'), document.title]
        .map(cleanText).find(title => title && !/^(?:抖音(?:网页版)?|douyin)(?:\s*[-|·]\s*记录美好生活)?$/i.test(title)) || '';
    }
    function add(element, item, title, author) {
      if (!element || !item || isLive(element, href) || [...blocked].some(scope => scope.contains(element) || element.contains(scope))) return;
      const resolvedTitle = (cleanText(title) || titleFor(element, item)).slice(0, 500);
      if (used.has(element)) {
        const existing = results.find(result => result.element === element && result.permalink === item.permalink);
        if (existing) { existing.title ||= resolvedTitle; existing.author ||= cleanText(author).slice(0, 200); }
        return;
      }
      if (results.some(existing => existing.placement === 'player' && existing.permalink === item.permalink && element.contains(existing.element))) return;
      used.add(element); results.push({ element, ...item, title: resolvedTitle, author: cleanText(author).slice(0, 200) });
    }
    if (!['www.douyin.com', 'douyin.com'].includes(page.hostname)) return results;
    const current = identify(href, href);
    if (current?.pageType === 'video') {
      const currentId = new URL(current.permalink).pathname.split('/').pop();
      const videos = [...document.querySelectorAll('video')].filter(video => {
        const style = document.defaultView.getComputedStyle(video);
        return !isLive(video, href) && !video.closest('[hidden],[aria-hidden="true"]') && style.display !== 'none' && style.visibility !== 'hidden';
      });
      const identity = video => {
        const owner = video.closest('[data-aweme-id],[data-video-id],[data-item-id]');
        return owner && (owner.getAttribute('data-aweme-id') || owner.getAttribute('data-video-id') || owner.getAttribute('data-item-id'));
      };
      const candidates = videos.filter(video => !identity(video) || identity(video) === currentId);
      const matched = candidates.filter(video => identity(video) === currentId);
      const pool = matched.length ? matched : videos;
      const visible = pool.map(video => {
        const box = video.getBoundingClientRect();
        const area = Math.max(0, Math.min(box.right, document.defaultView.innerWidth) - Math.max(0, box.left))
          * Math.max(0, Math.min(box.bottom, document.defaultView.innerHeight) - Math.max(0, box.top));
        return { video, area };
      }).filter(item => item.area > 0).sort((a,b) => b.area - a.area);
      // URL identity + explicit DOM identity win; otherwise require one clearly
      // dominant visible player. Paused state says nothing about its identity.
      const active = pool.length === 1 ? pool[0] : visible.length === 1 ? visible[0].video
        : visible.length > 1 && visible[0].area >= visible[1].area * 1.5 ? visible[0].video : null;
      if (active && candidates.includes(active)) {
        const scope = active.parentElement;
        add(active, current, titleFor(active, current),
          scope?.querySelector('[data-e2e="video-author-name"], [data-e2e="video-author"]')?.textContent);
        const result = results.find(item => item.element === active); if (result) result.placement = 'player';
      }
    }
    if (!current) for (const video of document.querySelectorAll('video')) {
      const style = document.defaultView.getComputedStyle(video);
      if (isLive(video, href) || video.closest('[hidden],[aria-hidden="true"]') || style.display === 'none' || ['hidden','collapse'].includes(style.visibility)) continue;
      const owner = video.closest(identitySelector);
      const scope = video.closest(feedSelector) ?? owner ?? video.closest('li,article');
      if (!scope) continue;
      if (scope.querySelectorAll('video').length > 1) { blocked.add(scope); continue; }
      const links = new Map();
      for (const anchor of scope.querySelectorAll(linkSelector)) {
        const item = identify(anchor.getAttribute('href'), href);
        if (item?.pageType === 'video' && new URL(item.permalink).hostname === 'www.douyin.com') links.set(item.permalink, item);
      }
      const id = domId(owner);
      let item = null;
      if (id) {
        const ids = new Set(['data-aweme-id','data-video-id','data-item-id'].map(key => owner.getAttribute(key)).filter(Boolean));
        if (!/^\d+$/.test(id) || ids.size !== 1) { blocked.add(scope); continue; }
        item = identify(`/video/${id}`, href);
        // Conflicting/ambiguous content links can indicate a recycled card mid-update.
        if (links.size && (links.size !== 1 || !links.has(item.permalink))) { blocked.add(scope); continue; }
      } else {
        if (links.size !== 1) { blocked.add(scope); continue; }
        item = links.values().next().value;
      }
      add(video, item, titleFor(video, item),
        scope.querySelector(authorSelector)?.textContent);
      const result = results.find(item => item.element === video); if (result) result.placement = 'player';
    }
    for (const anchor of document.querySelectorAll(linkSelector)) {
      const item = identify(anchor.getAttribute('href'), href);
      if (isLive(anchor, href)) continue;
      if (!item || new URL(item.permalink).hostname !== 'www.douyin.com') continue;
      let container = anchor.closest(cardSelector) ?? anchor;
      // A broad article/list wrapper may contain several distinct works: do not
      // attach the first work's button to the whole group or lose later items.
      const contained = new Set([...container.querySelectorAll(linkSelector)].map(link => identify(link.getAttribute('href'), href)?.permalink).filter(Boolean));
      if (contained.size > 1) container = anchor;
      const title = titleFor(anchor, item);
      add(container, item, title, boundScope(anchor, item)?.querySelector(authorSelector)?.textContent);
    }
    for (const element of document.querySelectorAll('[data-aweme-id], [data-video-id], [data-item-id]')) {
      if (isLive(element, href)) continue;
      const id = element.getAttribute('data-aweme-id') || element.getAttribute('data-video-id') || element.getAttribute('data-item-id');
      if (!/^\d+$/.test(id ?? '')) continue;
      const item = identify(`/video/${id}`, href);
      add(element.closest(cardSelector) ?? element, item, titleFor(element, item),
        element.querySelector(authorSelector)?.textContent);
    }
    return results;
  }
  globalThis.OneOPCAIClipperCards = Object.freeze({ identify, scan });
})();
