// Passive identity reads run in the extension service worker, using existing host
// permissions. The browser attaches HttpOnly Cookies; their values are never read.
export async function readPlatformSession(apiOrigin, fetcher = globalThis.fetch, signal = AbortSignal.timeout(5000)) {
  if (!['https://api.agentschool.me', 'http://localhost'].includes(apiOrigin)) return {state:'error',code:'wrong_api_origin',message:'平台接口配置无效'};
  try {
    const response = await fetcher(apiOrigin + '/v1/auth/me', {method:'GET', credentials:'include',
      redirect:'error',cache:'no-store',signal,headers:{'X-Requested-With':'agentschool'}});
    // A missing access cookie does not establish logout: it may have expired or
    // the browser may have withheld it from this extension context.
    if (response.status === 401) return {state:'needs_confirmation',message:'当前无法确认平台会话，请点击确认登录。'};
    if (!response.ok) return {state:'error',code:response.status===429?'rate_limited':'session_unavailable',
      message:response.status===429?'状态检查过于频繁，请稍后手动重试。':'平台会话暂不可确认，请重试；未改变网站登录状态。'};
    if (response.headers.get('content-type')?.split(';')[0].trim() !== 'application/json') throw new Error('invalid_response');
    const identity=await response.json();
    if (!identity || Array.isArray(identity) || typeof identity.id !== 'string' || !identity.id ||
        typeof identity.email !== 'string' || !identity.email) throw new Error('invalid_identity');
    return {state:'authenticated',profile:{name:typeof identity.full_name==='string'?identity.full_name.slice(0,100):'',
      email:identity.email.slice(0,255),tier:typeof identity.tier==='string'?identity.tier.slice(0,50):''}};
  } catch {return {state:'error',code:'session_unavailable',message:'平台会话暂不可确认，请重试；未改变网站登录状态。'};}
}

// Capture runs ONLY in the extension-owned first-party tab's ISOLATED world.
// Never returns credentials or accepts a request URL/method from the source page.
export async function runPlatformCommand(command, expectedOrigin, expectedUserId = null, apiOrigin) {
  if (!((expectedOrigin === 'https://agentschool.me' && apiOrigin === 'https://api.agentschool.me')
      || (expectedOrigin === 'http://localhost' && apiOrigin === 'http://localhost'))
      || location.origin !== expectedOrigin || !['/auth/login/', '/sheaf/'].includes(location.pathname)) {
    return { state: 'error', message: '平台页面已改变，请重试', code: 'wrong_context' };
  }
  const deadline = Date.now() + 12000;
  let userId = expectedUserId ?? null;
  const input = command.input;
  async function request(path, options = {}) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new Error('timeout');
    return fetch(new URL(path, apiOrigin).href, { ...options, cache: 'no-store', credentials: 'include', redirect: 'error',
      signal: AbortSignal.timeout(remaining), headers: { 'X-Requested-With': 'agentschool',
        ...(options.body ? { 'Content-Type': 'application/json' } : {}) } });
  }
  async function json(response) {
    if (!['application/json', 'application/problem+json'].includes(response.headers.get('content-type')?.split(';')[0].trim())) throw new Error('invalid_response');
    const body = await response.json();
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('invalid_response');
    return body;
  }
  function failure(response, body) {
    return { state: 'error', code: typeof body?.code === 'string' && /^[a-z][a-z0-9._-]{0,99}$/.test(body.code)
      ? body.code : response.status === 403 ? 'forbidden' : 'request_failed',
      message: response.status === 429 ? '操作过于频繁，请稍后重试'
        : response.status === 403 ? '当前操作未获授权，请检查平台服务权限'
        : `平台请求未确认（HTTP ${response.status}），请稍后重试`,
      retryAfter: /^\d{1,5}$/.test(response.headers.get('retry-after') ?? '') ? Number(response.headers.get('retry-after')) : undefined,
      requestId: typeof body?.request_id === 'string' ? body.request_id.slice(0, 100) : undefined, userId };
  }
  try {
    if (command.kind !== 'capture') throw new Error('invalid_command');
    let me = await request('/v1/auth/me');
    if (me.status === 401) {
      // An empty-cookie refresh can clear cookies; never race it against an active SSO callback.
      if (command.allowRefresh === false) return { state: 'login', message: '请完成平台统一登录后继续收藏', userId };
      const refreshed = await request('/v1/auth/session/refresh', { method: 'POST' });
      const body = refreshed.ok ? null : await json(refreshed);
      if ((refreshed.status === 403 && body?.code === 'auth.session-revoked')
          || (refreshed.status === 400 && (body?.error === 'invalid_grant' || body?.code === 'invalid_grant'))) {
        return { state: 'login', message: '会话已结束，请使用平台统一登录后继续收藏', userId };
      }
      if (!refreshed.ok) return failure(refreshed, body);
      me = await request('/v1/auth/me');
    }
    if (me.status === 401) return { state: 'login', message: '请登录后继续收藏' };
    if (!me.ok) return failure(me, await json(me));
    const identity = await json(me);
    if (typeof identity.id !== 'string' || !identity.id) throw new Error('invalid_identity');
    userId = identity.id;
    if (expectedUserId && userId !== expectedUserId) return { state: 'error', code: 'account_changed',
      message: '登录账号已变化。请再次点击，明确以新账号收藏', userId };
    const response = await request('/v1/sheaf/captures', { method: 'POST', body: JSON.stringify(input) });
    if (response.status === 401) return { state: 'login', message: '会话已失效，请登录后续办', userId };
    const body = await json(response);
    if (!response.ok) return failure(response, body);
    if (![200, 201].includes(response.status) || !['saved', 'duplicate'].includes(body.outcome)
        || typeof body.capture?.id !== 'string' || !body.capture.id || body.capture.rawUrl !== input.rawUrl) {
      throw new Error('invalid_receipt');
    }
    return { state: 'saved', outcome: body.outcome, captureId: body.capture.id, userId,
      message: body.outcome === 'duplicate' ? '已收藏（已有记录）' : '已收藏' };
  } catch {
    return { state: 'error', code: 'unconfirmed', userId,
      message: command.kind === 'capture' ? '网络或响应异常，尚未确认收藏。请重试，保留原幂等键避免重复'
        : '平台会话检查暂不可用，请稍后重试；未改变你的登录状态。' };
  }
}
