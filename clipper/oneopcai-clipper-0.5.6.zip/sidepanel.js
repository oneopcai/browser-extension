import { PLATFORM } from './config.js';
import { describeSource, PLATFORMS, sourcePlatform } from './context.js';

export const AGENT_ONBOARDING_PROMPT = `请先阅读 Agently Mail 官方指南 https://agent.qq.com/doc/cli-setup.md 和 AgentSchool 接入文档 ${PLATFORM.documentUrl} ，协助我准备可以接收验证码的 @agent.qq.com 邮箱。
已有邮箱请复用；没有时按官方 Node.js CLI 流程帮助准备，浏览器登录和 OAuth 授权由我本人完成。不要执行 Shell 包装脚本，不要索要、复制或记录密码、验证码、令牌和 API key，不要自动签发学生证。
完成后告诉我邮箱前缀，并引导我返回浏览器插件 OneOPCAI Clipper，点击“平台统一登录”，在官方登录窗口完成验证码验证。首次验证通过后，平台会自动创建账号，无需单独注册。浏览器插件OneOPCAI Clipper使用不要求安装 AgentSchool CLI；只有我另行要求完整 CLI 接入时再继续相关步骤。`;

export function mountPanel(api, doc = document, clock = globalThis) {
  const $ = id => doc.getElementById(id);
  const login = $('login');
  let runtime, settingsEvents, version, extensionId;
  try {
    runtime = api?.runtime; settingsEvents = api?.storage?.onChanged;
    version = runtime?.getManifest().version; extensionId = runtime?.id;
    if (!extensionId || typeof runtime.sendMessage !== 'function' || !version
        || typeof settingsEvents?.addListener !== 'function' || typeof settingsEvents?.removeListener !== 'function') throw new Error('panel_context_unavailable');
  } catch {
    $('notice').textContent = '插件连接已失效，请重新打开侧栏并刷新来源页面。';
    for (const id of ['account', 'library', 'refresh', 'display-mode']) $(id).disabled = true;
    return { ready: Promise.resolve(), refresh: async () => {}, inspect: async () => {}, stop() {} };
  }
  let context = null, profile = null, disposed = false, busy = false, authState = 'checking';
  let refreshSequence = 0, authSequence = 0, preferenceRevision = 0, savedMode = 'hover', loginRevision = 0;
  for (const platform of PLATFORMS) {
    const row = doc.createElement('li'), name = doc.createElement('span'), status = doc.createElement('small');
    row.dataset.platform = platform.id; name.textContent = platform.label; status.textContent = platform.enabled ? '已开放' : '暂未开放';
    row.append(name, status); $('platform-list').append(row);
  }
  let authNotice = null;
  const notice = (text, kind = 'general') => {
    if (kind === 'auth') clearAuthNotice();
    const target = $(login.open ? 'login-notice' : 'notice');
    if (kind !== 'auth' && authNotice?.target === target) authNotice = null;
    target.textContent = text ?? '';
    if (kind === 'auth') authNotice = { target, text: target.textContent };
  };
  const clearAuthNotice = () => {
    if (authNotice && authNotice.target.textContent === authNotice.text) authNotice.target.textContent = '';
    authNotice = null;
  };
  // Native extension APIs may throw before returning a Promise after a reload.
  const send = async message => {
    if (disposed) throw new Error('panel_closed');
    return await runtime.sendMessage(message);
  };
  const fail = () => { if (!disposed) notice('插件连接暂不可用，请重新打开侧栏并刷新来源页面后重试。'); };
  function clearTransient() {
    $('login-notice').textContent = ''; $('agent-prompt').value = ''; $('agent-prompt').hidden = true;
  }
  function closeLogin() {
    ++loginRevision; clearTransient(); const wasOpen = login.open;
    if (wasOpen) login.close();
    if (wasOpen && !disposed) $('account').focus();
    loginButton();
  }
  function openLogin() {
    if (profile || login.open || disposed) return;
    if (authState === 'error') { void inspect(); return; }
    ++loginRevision; $('login-notice').textContent = busy ? '正在完成上一次请求，请稍候。' : '';
    login.showModal(); $('continue-login').focus();
  }
  function loginButton() { $('continue-login').disabled = busy; }
  function showIdentity(result) {
    if (result?.state === 'authenticated' && result.profile) {
      clearAuthNotice();
      profile = result.profile; authState = 'authenticated';
      $('account').textContent = [...(profile.name || profile.email || '用')][0];
      $('account').title = '查看当前用户'; $('account').setAttribute('aria-label', '查看当前用户');
      $('account').classList.add('is-authenticated'); $('account').disabled = false;
      $('profile').textContent = [profile.name, profile.email, profile.tier ? `账号等级：${profile.tier}` : ''].filter(Boolean).join('\n');
      closeLogin();
    } else if (result?.state === 'login' || result?.state === 'needs_confirmation' || result?.state === 'login_pending') {
      clearAuthNotice();
      profile = null; authState = result.state;
      $('account').textContent = result.state === 'login_pending' ? '…' : result.state === 'needs_confirmation' ? '确认登录' : '登录';
      $('account').title = result.state === 'login_pending' ? '等待统一登录完成' : '平台统一登录';
      $('account').setAttribute('aria-label', result.state === 'login_pending' ? '等待统一登录完成' : '确认平台登录状态');
      $('account').classList.remove('is-authenticated'); $('account').disabled = false; $('profile').textContent = '';
      if (result.state === 'login_pending') notice(result.message, 'auth');
    } else {
      profile = null; authState = 'error';
      $('account').textContent = '重试'; $('account').title = '重新检查平台登录状态';
      $('account').setAttribute('aria-label', '重新检查平台登录状态'); $('account').disabled = false;
      $('account').classList.remove('is-authenticated'); $('profile').textContent = '';
      notice(result?.message || '平台会话暂不可确认，请重试；未改变网站登录状态。', 'auth');
    }
  }
  let inspectionPromise = null, inspectionDirty = false;
  function inspect(afterChange = false) {
    if (disposed) return Promise.resolve();
    if (inspectionPromise && afterChange) inspectionDirty = true;
    inspectionPromise ??= (async()=>{
      for (let attempt = 0; attempt < 2 && !disposed; attempt++) {
        inspectionDirty = false;
        const sequence = ++authSequence;
        try { const result = await send({ type: 'clipper.inspect' }); if (!disposed && !inspectionDirty && sequence === authSequence) showIdentity(result); }
        catch { if (!disposed && !inspectionDirty && sequence === authSequence) showIdentity({ state: 'error', message: '平台会话暂不可确认，请重试；未改变网站登录状态。' }); }
        if (!inspectionDirty) break;
        if (attempt === 1 && !disposed && sequence === authSequence) showIdentity({ state: 'error', message: '登录状态正在变化，请稍后重试。' });
      }
    })().finally(()=>{inspectionPromise=null;});
    return inspectionPromise;
  }
  function renderSummary() {
    const platform = sourcePlatform(context?.url);
    const count = platform?.enabled && Number.isSafeInteger(context?.total) && context.total >= 0 ? context.total : 0;
    for (const row of $('platform-list').children) {
      const selected = row.dataset.platform === platform?.id;
      row.classList.toggle('is-current', selected);
      if (selected) row.setAttribute('aria-current', 'true'); else row.removeAttribute('aria-current');
    }
    $('platform-hint').hidden = !platform || platform.enabled;
    $('platform').textContent = context ? describeSource(context.url) : '暂不支持此页面';
    $('page-title').textContent = context?.title ?? '';
    $('count').textContent = String(count);
    const saved = Number.isSafeInteger(context?.savedTotal) && context.savedTotal >= 0 && context.savedTotal <= count ? context.savedTotal : 0;
    $('saved-count').textContent = String(platform?.enabled ? saved : 0);
    $('empty').hidden = count > 0;
    $('empty').textContent = platform && !platform.enabled ? '暂未开放，敬请期待！' : '当前未识别到可收藏内容，请打开抖音视频或图文。';
  }
  async function refresh() {
    const sequence = ++refreshSequence;
    try {
      const result = await send({ type: 'clipper.panel' });
      if (disposed || sequence !== refreshSequence) return;
      context = result?.context ?? null; renderSummary();
    } catch { if (!disposed) fail(); }
  }
  $('version').textContent = `v${version}`;
  $('onboarding-guide').href = PLATFORM.documentUrl;
  $('account').addEventListener('click', openLogin);
  $('close-login').addEventListener('click', closeLogin);
  login.addEventListener('cancel', event => { event.preventDefault(); closeLogin(); });
  login.addEventListener('close', () => { if (!login.open) { ++loginRevision; clearTransient(); loginButton(); } });
  login.addEventListener('click', event => {
    if (event.target !== login) return;
    const box = login.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closeLogin();
  });
  $('agent-onboarding').addEventListener('click', async () => {
    if (!login.open || disposed) return;
    const revision = loginRevision;
    try {
      await doc.defaultView.navigator.clipboard.writeText(AGENT_ONBOARDING_PROMPT);
      if (!disposed && revision === loginRevision && login.open) notice('已复制，把指令发给你的 Agent；邮箱准备好后，回到这里登录。');
    } catch {
      if (disposed || revision !== loginRevision || !login.open) return;
      $('agent-prompt').hidden = false; $('agent-prompt').value = AGENT_ONBOARDING_PROMPT; $('agent-prompt').focus(); $('agent-prompt').select();
      notice('自动复制不可用，请手动复制下方指令，发给你的 Agent。');
    }
  });
  $('refresh').addEventListener('click', () => { void refresh(); void inspect(); });
  $('library').addEventListener('click', () => { send({ type: 'clipper.library' }).catch(fail); });
  $('continue-login').addEventListener('click', async () => {
    if (disposed || busy || !login.open) return;
    const sequence = ++authSequence;
    busy = true; loginButton(); notice('正在连接平台统一登录…', 'auth');
    try {
      const result = await send({ type: 'clipper.startLogin' });
      if (disposed || sequence !== authSequence) return;
      showIdentity(result);
      if (result?.state === 'authenticated') { notice('已连接平台登录状态，待收藏内容将继续处理。'); await refresh(); }
    } catch { if (!disposed && sequence === authSequence) showIdentity({ state: 'error', message: '统一登录暂不可用，请稍后重试。' }); }
    finally { busy = false; if (!disposed) loginButton(); }
  });
  function displayMode(value) {
    $('display-mode').checked = value === 'all';
    $('display-mode-state').textContent = value === 'all' ? '全部显示' : '悬停显示';
  }
  const changed = (changes, area) => {
    if (disposed) return;
    if (area === 'sync' && Object.hasOwn(changes, 'buttonDisplayMode')) { preferenceRevision++; savedMode = changes.buttonDisplayMode.newValue === 'all' ? 'all' : 'hover'; displayMode(savedMode); }
  };
  try { settingsEvents.addListener(changed); } catch { fail(); }
  const revision = preferenceRevision;
  Promise.resolve().then(() => api.storage.sync.get('buttonDisplayMode')).then(settings => { if (!disposed && revision === preferenceRevision) { savedMode = settings.buttonDisplayMode === 'all' ? 'all' : 'hover'; displayMode(savedMode); } }, fail);
  $('display-mode').addEventListener('change', async () => {
    if (disposed) return;
    ++preferenceRevision;
    const value = $('display-mode').checked ? 'all' : 'hover'; displayMode(value); $('display-mode').disabled = true;
    try { await api.storage.sync.set({ buttonDisplayMode: value }); if (!disposed) savedMode = value; }
    catch { if (!disposed) { displayMode(savedMode); notice('显示设置未保存，请重试。'); } }
    finally { if (!disposed) $('display-mode').disabled = false; }
  });
  const poll = clock.setInterval(() => { void refresh(); }, 1500);
  const sessionChanged = (message, sender) => {
    if (disposed || sender?.id !== extensionId || sender.tab) return;
    if (message?.type === 'clipper.sessionChanged') void inspect(true);
    if (message?.type === 'clipper.sessionUnconfirmed') { ++authSequence; showIdentity({state:'error',message:'插件暂时无法确认登录状态。请在登录窗口检查登录是否完成；若网站已登录，请检查浏览器 Cookie 隐私设置后重试。'}); }
  };
  const focused = () => { if (!disposed) void inspect(); };
  const sessionEvents = runtime.onMessage;
  try { sessionEvents?.addListener(sessionChanged); } catch { fail(); }
  doc.defaultView?.addEventListener('focus', focused);
  const visible = () => { if (!disposed && doc.visibilityState === 'visible') void inspect(); };
  doc.addEventListener('visibilitychange',visible);
  const stop = () => {
    if (disposed) return;
    disposed = true; closeLogin(); clock.clearInterval(poll);
    doc.defaultView?.removeEventListener('focus', focused);
    doc.removeEventListener('visibilitychange',visible);
    try { sessionEvents?.removeListener(sessionChanged); } catch { /* Expired context. */ }
    try { settingsEvents.removeListener(changed); } catch { /* Extension reload must not prevent local field/timer cleanup. */ }
  };
  doc.defaultView?.addEventListener('pagehide', stop, { once: true });
  const ready = Promise.all([refresh(), inspect()]); loginButton();
  return { ready, refresh, inspect, stop };
}
if (globalThis.chrome) mountPanel(globalThis.chrome);
