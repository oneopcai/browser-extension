import { PLATFORM } from './config.js';
import { captureInput } from './target.js';
import { readPlatformSession, runPlatformCommand } from './session.js';
import { sourcePlatform } from './context.js';

const STATE_KEY = 'clipperSessionV1';
const TTL = 30 * 60 * 1000;
const LIMIT = 80;
const enabled = value => sourcePlatform(value)?.enabled === true;
const publicResult = op => ({ state: op.state,
  message: op.state === 'saved' && !op.input.pageMeta?.title?.trim()
    ? '链接已收藏，但本次保存未获取标题；重复点击返回原回执，不会自动补写标题。' : op.message,
  titleCaptured: Boolean(op.input.pageMeta?.title?.trim()), code: op.code,
  captureId: op.captureId, outcome: op.outcome, requestId: op.requestId, rawUrl: op.input.rawUrl });

function committedUrl(tab) {
  if (typeof tab?.url !== 'string' || !tab.url.trim()) return null;
  try { const url = new URL(tab.url); return ['http:', 'https:'].includes(url.protocol) ? url : null; }
  catch { return null; }
}

// Runs in the verified owned first-party document's MAIN world. This is only a
// standard same-origin revalidation hint; it never carries identity or credentials.
export function announceCompletedSession(expectedOrigin) {
  if (location.origin !== expectedOrigin || !['/sheaf/', '/dashboard', '/dashboard/'].includes(location.pathname)) return false;
  try {
    const channel = new BroadcastChannel('oneopcai.browser-session');
    channel.postMessage({type:'session-changed'}); channel.close(); return true;
  } catch { return false; }
}

export function createCoordinator(api, { now = Date.now, uuid = () => crypto.randomUUID(),
  pause = ms => new Promise(resolve => setTimeout(resolve, ms)), fetchSession = globalThis.fetch } = {}) {
  let state, loadPromise, bridgePromise, loginPromise, serial = Promise.resolve(), platformSerial = Promise.resolve();
  const running = new Map(), resume = new Set();
  let inspectionPromise = null;
  async function load() {
    loadPromise ??= (async () => {
      await api.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
      state = (await api.storage.session.get(STATE_KEY))[STATE_KEY] ?? { bridge: null, operations: [] };
      state.operations = state.operations.filter(op => op.origin === PLATFORM.webOrigin && now() - op.createdAt < TTL);
      await api.storage.session.set({ [STATE_KEY]: state });
    })();
    await loadPromise;
  }
  const persist = () => api.storage.session.set({ [STATE_KEY]: state });
  function senderAllowed(sender) {
    if (!sender || typeof sender.id !== 'string' || sender.id !== api.runtime.id || (sender.frameId ?? 0) !== 0) return false;
    if (sender.url === api.runtime.getURL('sidepanel.html')) return true;
    try { const u = new URL(sender.url); return u.protocol === 'https:'
      && enabled(u.href)
      && Number.isInteger(sender.tab?.id); } catch { return false; }
  }
  async function notify(op) {
    if (Number.isInteger(op.tabId)) {
      try { await api.tabs.sendMessage(op.tabId, { type: 'clipper.result', result: publicResult(op) }, { frameId: 0 }); } catch { /* Source tab may have closed. */ }
    }
  }
  async function ownedTab(origin) {
    if (state.bridge?.origin === origin) {
      try {
        const tab = await api.tabs.get(state.bridge.id);
        // A live owned tab must not be orphaned just because it navigated. Let
        // readyTab reject its context; only a closed tab needs a replacement.
        if (Number.isInteger(tab?.id) && tab.id === state.bridge.id) return tab;
      } catch { /* Recreate a closed extension-owned tab. */ }
    }
    // The application gate owns anonymous navigation. Starting at a login page
    // would send an already-authenticated bridge to an unrelated default page.
    const tab = await api.tabs.create({ url: `${origin}/sheaf/`, active: false });
    if (!Number.isInteger(tab?.id)) throw new Error('平台标签页未创建成功');
    state.bridge = { id: tab.id, origin }; await persist(); return tab;
  }
  async function readyTab(origin) {
    bridgePromise ??= ownedTab(origin).finally(() => { bridgePromise = null; });
    const first = await bridgePromise;
    for (let i = 0; i < 80; i++) {
      const tab = await api.tabs.get(first.id);
      const u = committedUrl(tab);
      // pendingUrl describes an uncommitted navigation, never an injection permit.
      if (u && tab.status === 'complete' && !tab.pendingUrl) return { tab, ready: u.origin === origin && ['/auth/login/', '/sheaf/'].includes(u.pathname) };
      await pause(150);
    }
    throw new Error('平台页面尚未加载完成，请检查收藏站点后重试');
  }
  function invoke(command, origin, userId = null) {
    // Serialize refresh/login/capture so cookie rotation cannot race another command.
    const work = platformSerial.then(async () => {
      const { tab, ready } = await readyTab(origin);
      if (!ready) throw new Error('首方后台页已离开预置平台，请关闭该页后重试');
      const allowRefresh = !(state.login && now() - state.login.createdAt < TTL);
      const rows = await api.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] },
        world: 'ISOLATED', func: runPlatformCommand, args: [{ ...command, allowRefresh }, origin, userId, PLATFORM.apiOrigin] });
      return rows?.find(row => row.frameId === 0)?.result;
    });
    platformSerial = work.catch(() => {});
    return work;
  }
  async function execute(op) {
    await load();
    if (!enabled(op.input.rawUrl)) {
      Object.assign(op, { state: 'error', code: 'platform_unavailable', message: '暂未开放，敬请期待！' });
      await persist(); await notify(op); return;
    }
    if (now() - op.createdAt >= TTL) {
      Object.assign(op, { state: 'error', code: 'expired', message: '待办已过期，请再次点击收藏' });
      await persist(); await notify(op); return;
    }
    try {
      const result = await invoke({ kind: 'capture', input: op.input }, op.origin, op.userId ?? null);
      if (!result || !['saved', 'login', 'error'].includes(result.state)) throw new Error('未收到有效收藏回执');
      Object.assign(op, result);
      await persist(); await notify(op);
    } catch (error) {
      Object.assign(op, { state: 'error', code: 'transport_error',
        message: `收藏未确认：${error?.message ?? '平台连接失败'}。点击可用原键重试` });
      await persist(); await notify(op);
    }
  }
  function schedule(op, fromNavigation = false) {
    if (running.has(op.id)) { if (fromNavigation) resume.add(op.id); return; }
    const work = serial.then(() => execute(op));
    running.set(op.id, work);
    serial = work.catch(() => {}).finally(() => {
      running.delete(op.id);
      if (resume.delete(op.id) && ['saving', 'login'].includes(op.state)) schedule(op);
    });
  }
  async function message(message, sender) {
    if (!senderAllowed(sender)) return { state: 'error', message: '来源不受信任', code: 'sender_rejected' };
    await load();
    const isPanel = sender.url === api.runtime.getURL('sidepanel.html');
    if (message.type === 'clipper.open') return { state: 'opened' };
    if (message.type === 'clipper.panel') {
      if (!isPanel) return { state: 'error', code: 'sender_rejected' };
      const [active] = await api.tabs.query({ active: true, lastFocusedWindow: true });
      let context = null;
      if (Number.isInteger(active?.id)) {
        if (sourcePlatform(active.url) && !enabled(active.url)) {
          context = { tabId: active.id, url: active.url, title: String(active.title ?? '').slice(0, 500), total: 0, savedTotal: 0 };
        } else {
        try {
          const raw = await api.tabs.sendMessage(active.id, { type: 'clipper.context:get' }, { frameId: 0 });
          if (raw && typeof raw.url === 'string') {
            const source = new URL(raw.url);
            if (enabled(source.href)) {
              if (!Number.isSafeInteger(raw.total) || raw.total < 0) throw new Error('页面识别数量无效');
              if (!Number.isSafeInteger(raw.savedTotal) || raw.savedTotal < 0 || raw.savedTotal > raw.total) throw new Error('页面收藏数量无效');
              context = { tabId: active.id, url: source.href, title: String(raw.title ?? '').slice(0, 500), total: raw.total, savedTotal: raw.savedTotal };
            }
          }
        } catch { /* Unsupported or no longer accessible active tab. */ }
        }
      }
      return { context };
    }
    if (message.type === 'clipper.inspect' || message.type === 'clipper.startLogin') {
      if (!isPanel) return { state: 'error', code: 'sender_rejected' };
      if (message.type === 'clipper.startLogin') {
        loginPromise ??= startLogin().finally(() => { loginPromise = null; });
        return loginPromise;
      }
      const result = await inspectSession();
      if (result.state === 'needs_confirmation' && state.login && !state.login.unconfirmed && now() - state.login.createdAt < TTL) return { state: 'login_pending', message: '请在统一登录页完成验证，完成后将自动连接。' };
      return result;
    }
    if (message.type === 'clipper.library') {
      if (!isPanel) return { state: 'error', code: 'sender_rejected' };
      await api.tabs.create({ url: PLATFORM.libraryUrl, active: true });
      return { state: 'opened' };
    }
    if (message.type === 'clipper.status') {
      const origin = PLATFORM.webOrigin;
      return state.operations.filter(op => op.tabId === (sender.tab?.id ?? null) && op.origin === origin && now() - op.createdAt < TTL).map(publicResult);
    }
    if (message.type !== 'clipper.save') return { state: 'error', message: '不支持的操作' };
    if (isPanel) return { state: 'error', code: 'source_click_required', message: '请在原内容旁点击收藏按钮' };
    const input = captureInput(message.data);
    if (!enabled(input.rawUrl)) return { state: 'error', code: 'platform_unavailable', message: '暂未开放，敬请期待！' };
    // Content scripts can only submit a specific item from their own supported platform.
    if (sender.url !== api.runtime.getURL('sidepanel.html')) {
      const source = new URL(input.rawUrl), page = new URL(sender.url);
      if (source.hostname !== page.hostname && !(['douyin.com', 'www.douyin.com'].includes(source.hostname)
          && ['douyin.com', 'www.douyin.com'].includes(page.hostname))) throw new Error('收藏来源与页面不符');
      if ((page.hostname.includes('douyin') && !/^\/(video|note)\/\d+\/?$/.test(source.pathname))
          || (page.hostname === 'mp.weixin.qq.com' && !/^\/s(?:\/|$)/.test(source.pathname))) throw new Error('需要具体内容链接');
    }
    const origin = PLATFORM.webOrigin;
    const tabId = sender.tab?.id ?? null;
    let op = state.operations.findLast(item => item.origin === origin && item.tabId === tabId
      && item.input.rawUrl === input.rawUrl && now() - item.createdAt < TTL);
    if (op?.state === 'saved') return publicResult(op);
    if (!op || op.code === 'account_changed') {
      state.operations = state.operations.filter(item => now() - item.createdAt < TTL);
      if (state.operations.length >= LIMIT) {
        const index = state.operations.findIndex(item => !running.has(item.id) && ['saved', 'error'].includes(item.state));
        if (index < 0) throw new Error('待办过多，请先完成登录或处理已有收藏');
        state.operations.splice(index, 1);
      }
      op = { id: uuid(), origin, tabId, input: { ...input, clientRequestId: uuid() }, createdAt: now(), state: 'saving' };
      state.operations.push(op);
    }
    if (!running.has(op.id)) {
      Object.assign(op, { state: 'saving', code: undefined, message: '正在收藏…' });
      await persist(); schedule(op);
    }
    return publicResult(op);
  }
  async function notifySession(type = 'clipper.sessionChanged') {
    try { await api.runtime.sendMessage({ type }); } catch { /* A sidebar is not always open. */ }
  }
  function inspectSession() {
    inspectionPromise ??= readPlatformSession(PLATFORM.apiOrigin,fetchSession).finally(()=>{inspectionPromise=null;});
    return inspectionPromise;
  }
  function resumeConfirmedIntents() {
    for (const op of state.operations) if (op.state === 'login' && now() - op.createdAt < TTL) schedule(op,true);
  }
  async function startLogin() {
    const current = await inspectSession();
    if (current.state !== 'needs_confirmation') return current;
    if (state.login && now() - state.login.createdAt < TTL) {
      try {
        const tab = await api.tabs.get(state.login.tabId);
        if (tab?.id === state.login.tabId && tab.windowId === state.login.windowId) {
          await api.tabs.update(tab.id, { active: true });
          return { state: 'login_pending', message: '请在统一登录页完成验证。' };
        }
      } catch { /* The extension-owned login tab may have closed. */ }
    }
    // 统一登录在当前窗口以新标签页打开（Master 裁决：不再弹独立小窗）；
    // 完成后 landing 清理逻辑会移除本插件创建的该标签页并自动续办收藏。
    const tab = await api.tabs.create({ url: PLATFORM.loginUrl, active: true });
    if (!Number.isInteger(tab?.id)) throw new Error('登录标签页未创建成功，请重试');
    state.login = { windowId: tab.windowId, tabId: tab.id, createdAt: now() };
    await persist();
    return { state: 'login_pending', message: '请在统一登录页完成验证，完成后将自动连接。' };
  }
  async function updated(tabId, change, tab) {
    await load();
    if (change.status !== 'complete') return;
    const u = committedUrl(tab);
    if (!u || tab?.pendingUrl || u.origin !== PLATFORM.webOrigin) return;
    const login = state.login;
    const landing = url => url?.origin === PLATFORM.webOrigin && ['/sheaf/', '/dashboard', '/dashboard/'].includes(url.pathname);
    if (login?.tabId === tabId && tab.windowId === login.windowId && landing(u)) {
      // A pre-callback read can finish late; completion needs a fresh server read.
      if (inspectionPromise) await inspectionPromise;
      const result = await inspectSession();
      if (result.state === 'authenticated' && state.login === login) {
        state.login = null; await persist();
        resumeConfirmedIntents();
        // Close only the tab this extension created, after confirming its current identity and location.
        try {
          const current = await api.tabs.get(tabId), url = committedUrl(current);
          if (current?.id === tabId && current.windowId === login.windowId && !current.pendingUrl
              && landing(url)) {
            // Do not close the popup before another first-party document learns
            // that it should revalidate. Its SPA may not have run its own /me yet.
            await api.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',
              func:announceCompletedSession,args:[PLATFORM.webOrigin]});
            const latest=await api.tabs.get(tabId);
            if (latest?.id===tabId && latest.windowId===login.windowId && !latest.pendingUrl && landing(committedUrl(latest)))
              await api.tabs.remove(tabId);
          }
        } catch { /* The user may have already closed or navigated the login tab. */ }
      } else if (state.login === login) {
        // A first-party landing does not prove that the extension may send the
        // same cookies. Leave the window under user control and make the
        // uncertainty visible instead of waiting forever.
        state.login.unconfirmed = true; await persist();
        await notifySession('clipper.sessionUnconfirmed');
        return;
      }
    }
    await notifySession();
    if (tabId !== state.bridge?.id || !['/auth/login/', '/sheaf/'].includes(u.pathname)) return;
    for (const op of state.operations) if (['saving', 'login'].includes(op.state) && op.origin === state.bridge.origin) schedule(op, true);
  }
  async function removed(tabId) {
    await load();
    if (state.login?.tabId === tabId) { state.login = null; await persist(); await notifySession(); }
    if (state.bridge?.id !== tabId) return;
    state.bridge = null;
    for (const op of state.operations) if (op.state === 'login') {
      Object.assign(op, { state: 'error', code: 'login_closed', message: '平台后台页已关闭，点击收藏可重新连接并续办' });
      await notify(op);
    }
    await persist();
  }
  function open(message, sender) {
    if (!senderAllowed(sender) || !['clipper.open', 'clipper.save'].includes(message.type) || !Number.isInteger(sender.tab?.windowId)) return;
    // Must run before any await: Chrome only accepts open during the user's gesture.
    return api.sidePanel.open({ windowId: sender.tab.windowId });
  }
  return { message, open, updated, removed, settled: async () => { while (running.size) await serial; } };
}

if (globalThis.chrome?.runtime?.onMessage) {
  const coordinator = createCoordinator(chrome);
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (typeof message?.type !== 'string' || !message.type.startsWith('clipper.')) return;
    try { coordinator.open(message, sender)?.catch(() => {}); } catch { /* Browser may reject a gesture from an expired page. */ }
    coordinator.message(message, sender).then(reply, () => reply({ state: 'error', message: '平台操作未确认，请检查输入或连接后重试' }));
    return true;
  });
  chrome.tabs.onUpdated.addListener((...args) => { void coordinator.updated(...args).catch(() => {}); });
  chrome.tabs.onRemoved.addListener(id => { void coordinator.removed(id).catch(() => {}); });
}
