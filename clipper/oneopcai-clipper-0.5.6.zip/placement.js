// Layout only: page geometry is untrusted and never used as an API destination.
(() => {
  globalThis.OneOPCAIClipperPlacement = function (doc, width, height) {
    const candidates = new Set(doc.querySelectorAll('nav,[role="navigation"],#douyin-navigation,[data-e2e="douyin-navigation"],[data-e2e="sidebar"]'));
    function sidebarBox(element) {
      const style = doc.defaultView.getComputedStyle(element), box = element.getBoundingClientRect();
      if (element.getAttribute('aria-hidden') === 'true' || style.display === 'none'
          || ['hidden', 'collapse'].includes(style.visibility) || style.opacity === '0') return null;
      // A left vertical rail, not a horizontal header or a collection on the right.
      return box.width > 0 && box.width <= Math.min(420, width / 2) && box.left <= 48
        && box.right > 0 && box.bottom > 100 && box.top < Math.min(200, height / 3)
        && box.height >= Math.min(180, height / 2) ? box : null;
    }
    // Some platform layouts use plain divs. Identify their shared navigation rail
    // from multiple distinct, visible menu links instead of guessing hashed classes.
    const labels = new Set(['首页', '推荐', '精选', '关注', '朋友', '我的', '直播', '热门', '放映厅', '短剧', '知识', '同城']);
    const groups = new Map();
    for (const link of doc.querySelectorAll('a[href]')) {
      const label = link.textContent.trim();
      if (!labels.has(label)) continue;
      const linkStyle = doc.defaultView.getComputedStyle(link), linkBox = link.getBoundingClientRect();
      if (link.closest('[hidden],[aria-hidden="true"]') || linkStyle.display === 'none'
          || ['hidden', 'collapse'].includes(linkStyle.visibility) || linkBox.width <= 0 || linkBox.height <= 0) continue;
      let url;
      try { url = new URL(link.getAttribute('href'), doc.baseURI); } catch { continue; }
      if (url.origin !== doc.location.origin || !/^\/(?:discover|follow|friend|hot|recommend|live|channel|user\/self)?\/?$/.test(url.pathname)) continue;
      for (let element = link.parentElement, depth = 0; element && depth < 6; element = element.parentElement, depth++) {
        if (!sidebarBox(element)) continue;
        if (!groups.has(element)) groups.set(element, new Set());
        groups.get(element).add(label);
      }
    }
    for (const [element, distinct] of groups) if (distinct.size >= 3) candidates.add(element);
    let anchor = null, box = null;
    for (const element of candidates) {
      const current = sidebarBox(element);
      if (current && (!box || current.right > box.right)) { anchor = element; box = current; }
    }
    // Content order/geometry never participates. A missing rail has width zero.
    const left = Math.min(Math.max(12, (box?.right ?? 0) + 12), Math.max(0, width - 12));
    return { anchor, left, top: Math.min(Math.max(12, (box?.top ?? 0) + 12), Math.max(0, height - 40)),
      maxWidth: Math.max(0, width - left - 12) };
  };
  // A portal is outside the source's clipping tree. Reapply its actual visible
  // bounds and paint order instead of pinning a scrolled-away button to the top.
  globalThis.OneOPCAIClipperButtonVisible = function (doc, target, button, right, top, permalink) {
    const view = doc.defaultView, source = target.getBoundingClientRect();
    const measured = button.getBoundingClientRect();
    const box = measured.width > 0 && measured.height > 0 ? measured
      : { left: right - 1, right, top, bottom: top + 32 };
    const clip = { left: Math.max(8, source.left), right: Math.min(view.innerWidth - 8, source.right),
      top: Math.max(8, source.top), bottom: Math.min(view.innerHeight - 8, source.bottom) };
    for (let node = target; node && node !== doc.documentElement; node = node.parentElement) {
      const style = view.getComputedStyle(node);
      if (node.hidden || node.getAttribute('aria-hidden') === 'true' || style.display === 'none'
          || ['hidden', 'collapse'].includes(style.visibility) || style.opacity === '0') return false;
      if (node === target) continue;
      const x = /hidden|clip|auto|scroll|overlay/.test(style.overflowX || style.overflow);
      const y = /hidden|clip|auto|scroll|overlay/.test(style.overflowY || style.overflow);
      if (x || y) {
        const rect = node.getBoundingClientRect();
        if (x) { clip.left = Math.max(clip.left, rect.left); clip.right = Math.min(clip.right, rect.right); }
        if (y) { clip.top = Math.max(clip.top, rect.top); clip.bottom = Math.min(clip.bottom, rect.bottom); }
      }
    }
    if (box.left < clip.left || box.right > clip.right || box.top < clip.top || box.bottom > clip.bottom) return false;
    if (typeof doc.elementsFromPoint !== 'function') return true;
    const points = [[box.left + .5, box.top + .5], [box.right - .5, box.top + .5],
      [box.left + .5, box.bottom - .5], [box.right - .5, box.bottom - .5],
      [(box.left + box.right) / 2, (box.top + box.bottom) / 2]];
    const matchedLayers = new Map();
    function sameWorkLayer(layer) {
      if (matchedLayers.has(layer)) return matchedLayers.get(layer);
      const identify = globalThis.OneOPCAIClipperCards?.identify;
      const expected = typeof permalink === 'string' && identify?.(permalink, doc.baseURI);
      const ids = [], links = new Set();
      for (const node of [layer, ...layer.querySelectorAll('[data-aweme-id],[data-video-id],[data-item-id],a[href]')]) {
        for (const key of ['data-aweme-id', 'data-video-id', 'data-item-id']) if (node.hasAttribute(key)) ids.push(node.getAttribute(key));
        if (node.matches('a[href]')) {
          const item = identify?.(node.getAttribute('href'), doc.baseURI);
          if (item) links.add(item.permalink);
        }
      }
      const id = expected?.permalink.split('/').pop();
      const matches = Boolean(expected && (ids.length || links.size)
        && ids.every(value => /^\d+$/.test(value) && value === id)
        && [...links].every(value => value === expected.permalink));
      matchedLayers.set(layer, matches); return matches;
    }
    return points.every(([x, y]) => {
      const painted = doc.elementsFromPoint(x, y).find(node => !node.closest('[data-oneopcai-clipper]'));
      if (!painted) return false;
      if (target === painted || target.contains(painted) || painted.contains(target)) return true;
      // Autoplay adds sibling images, controls and preview layers. They do not
      // make the content itself disappear. Only external fixed/sticky chrome
      // clips the portal; a proven same-work preview is part of that content.
      for (let layer = painted; layer && layer !== doc.documentElement; layer = layer.parentElement) {
        if (layer.contains(target) || !['fixed', 'sticky'].includes(view.getComputedStyle(layer).position)) continue;
        if (layer.matches('header,nav,[role="banner"],[role="navigation"],[role="tablist"]') || !sameWorkLayer(layer)) return false;
      }
      return true;
    });
  };
})();
