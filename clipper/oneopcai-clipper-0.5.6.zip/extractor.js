/**
 * 页面适配器（最小集）：提取 permalink + 可见元信息。
 *
 * 约定（对应 Sheaf CaptureCreate.pageMeta——客户端声明性元信息，只保存
 * 不联网解析、不当事实源）：
 * - permalink：canonical link 优先（页面自证的规范地址），否则 location.href；
 * - title：og:title → document.title；
 * - author：meta author → og:article:author；
 * - pageType：og:type（≤64 字符，超出截断）；
 * - capturedText：用户选中文本优先（最多 2000 字符），否则 meta description。
 *
 * 该函数经 chrome.scripting.executeScript 注入页面执行——必须自包含、
 * 不引用外部符号。
 */
export function extractInPage() {
  const meta = (selector) => {
    const element = document.querySelector(selector);
    const content = element ? element.getAttribute("content") : "";
    return content && content.trim() ? content.trim() : null;
  };

  const canonical = document.querySelector('link[rel="canonical"]');
  let permalink = location.href;
  if (canonical?.getAttribute("href")) {
    try {
      const url = new URL(canonical.getAttribute("href"), document.baseURI);
      if (["http:", "https:"].includes(url.protocol) && !url.username && !url.password) permalink = url.href;
    } catch { /* Bad canonical metadata must not prevent collecting the actual page. */ }
  }

  const current = new URL(location.href);
  let platform = "web", adapter = "generic", contentType = meta('meta[property="og:type"]');
  const text = selector => document.querySelector(selector)?.textContent?.trim() || null;
  let title = meta('meta[property="og:title"]') ?? document.title ?? null;
  let author = meta('meta[name="author"]') ?? meta('meta[property="article:author"]');
  if (current.hostname === "www.douyin.com" || current.hostname === "douyin.com") {
    platform = "douyin";
    const detail = current.pathname.match(/^\/(video|note)\/(\d+)(?:\/|$)/);
    const id = detail?.[2] || current.searchParams.get("modal_id");
    // SPA feeds often keep a homepage canonical while a particular video is open.
    if (id && /^\d+$/.test(id)) { const kind = detail?.[1] || 'video'; permalink = `https://www.douyin.com/${kind}/${id}`; adapter = "douyin-video"; contentType = kind === 'note' ? 'article' : 'video'; }
    else { permalink = current.href; contentType = "douyin.page"; }
  } else if (current.hostname === "v.douyin.com") {
    platform = "douyin"; permalink = current.href; contentType = "douyin.link";
  } else if (current.hostname === "mp.weixin.qq.com") {
    platform = "wechat"; permalink = current.href;
    if (/^\/s(?:\/|$)/.test(current.pathname)) {
      adapter = "wechat-article"; contentType = "article";
      title = meta('meta[property="og:title"]') || text("#activity-name") || title;
      author = author || text("#js_name");
    }
  } else if (current.hostname === "xiaohongshu.com" || current.hostname.endsWith(".xiaohongshu.com")) {
    platform = "xiaohongshu"; permalink = current.href; // Preserve xsec_token, if present; generic collection only.
  } else if (current.hostname === "bilibili.com" || current.hostname.endsWith(".bilibili.com") || current.hostname === "b23.tv") {
    platform = "bilibili"; permalink = current.href; // Dedicated media extraction remains downstream work.
  }
  const selection = window.getSelection?.()?.toString?.() ?? "";

  return {
    permalink,
    title,
    author,
    pageType: contentType,
    platform,
    adapter,
    capturedText: ((selection && selection.trim()) || meta('meta[name="description"]'))?.slice(0, 2000) ?? null,
  };
}
