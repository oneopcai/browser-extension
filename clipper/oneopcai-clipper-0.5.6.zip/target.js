export function captureInput(data) {
  if (!data || typeof data.permalink !== 'string') throw new Error('缺少内容链接');
  const source = new URL(data.permalink);
  if (!['https:', 'http:'].includes(source.protocol) || source.username || source.password || source.href.length > 4000) throw new Error('链接无效');
  const pageMeta = {};
  for (const [key, limit] of [['title', 500], ['author', 200], ['pageType', 64], ['capturedText', 2000]]) {
    if (typeof data[key] === 'string' && data[key].trim()) pageMeta[key] = data[key].slice(0, limit);
  }
  return { rawUrl: source.href, ...(Object.keys(pageMeta).length ? { pageMeta } : {}) };
}
